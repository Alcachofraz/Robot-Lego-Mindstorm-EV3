public interface Iteration {
    public boolean iterate();
}
