public interface Trajectory {
    public boolean run(Robot robot);
}
